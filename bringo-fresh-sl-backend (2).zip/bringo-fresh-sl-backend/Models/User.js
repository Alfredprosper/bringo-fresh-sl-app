const mongoose = require('mongoose');

// Define the schema for users
const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  phoneNumber: String,
  password: String,
  role: { type: String, enum: ['user', 'chef', 'admin'], default: 'user' },
  isApproved: { type: Boolean, default: false }, // chefs need approval
});

// Export the User model to be used elsewhere
module.exports = mongoose.model('User', userSchema);