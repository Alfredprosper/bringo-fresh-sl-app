const mongoose = require('mongoose');

const chefSchema = new mongoose.Schema({
  name: String,
  location: String,
  menu: [
    {
      title: String,
      description: String,
      price: Number
    }
  ]
});

module.exports = mongoose.model('Chef', chefSchema);