// routes/orderRoutes.js
const express = require('express');
const router = express.Router();
const Order = require('../models/Order');

// Place a new order
router.post('/', async (req, res) => {
  const { userId, chefId, items, total } = req.body;

  try {
    const order = new Order({
      userId,
      chefId,
      items,
      total,
    });

    await order.save();
    res.json({ success: true, message: 'Order placed', order });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to place order' });
  }
});

// Get all orders for a specific user
router.get('/user/:userId', async (req, res) => {
  try {
    const orders = await Order.find({ userId: req.params.userId });
    res.json({ success: true, orders });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error getting user orders' });
  }
});

// Get all orders for a specific chef
router.get('/chef/:chefId', async (req, res) => {
  try {
    const orders = await Order.find({ chefId: req.params.chefId });
    res.json({ success: true, orders });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error getting chef orders' });
  }
});

// Update order status (e.g. accepted or delivered)
router.put('/:orderId', async (req, res) => {
  const { status } = req.body;

  try {
    const updatedOrder = await Order.findByIdAndUpdate(
      req.params.orderId,
      { status },
      { new: true }
    );

    res.json({ success: true, order: updatedOrder });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update order' });
  }
});

module.exports = router;