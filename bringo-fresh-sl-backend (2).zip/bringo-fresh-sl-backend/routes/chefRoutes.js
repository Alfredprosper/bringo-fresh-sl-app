// routes/chefRoutes.js
const express = require('express');
const router = express.Router();
const User = require('../models/User');

// Get all approved chefs
router.get('/', async (req, res) => {
  try {
    const chefs = await User.find({ role: 'chef', isApproved: true });
    res.json({ success: true, chefs });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error fetching chefs' });
  }
});

// Admin approves a chef
router.put('/approve/:chefId', async (req, res) => {
  try {
    const chef = await User.findByIdAndUpdate(
      req.params.chefId,
      { isApproved: true },
      { new: true }
    );
    res.json({ success: true, chef });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error approving chef' });
  }
});

module.exports = router;